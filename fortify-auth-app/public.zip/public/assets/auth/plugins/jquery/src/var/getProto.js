define( function() {
	"use strict";

	return Object.getPrototypeOf;
} );
